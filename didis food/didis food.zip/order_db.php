<?php
include('connection.php');
session_start();

$quantity=$_POST['quantity'];
$place_order=$_POST['place'];

$query="insert into vieworder (quantity,order_location) value ( '$quantity', '$place_order')";
$result=mysqli_query($conn,$query);
if($result)
{
echo "correct";
}
else{
    echo "incorrect";
}




?>