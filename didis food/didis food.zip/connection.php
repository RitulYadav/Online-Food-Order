<?php
$servername = "localhost";
$admin = "root";
$password = "";
$databasename = "food";
$conn = mysqli_connect( $servername, $admin, $password, $databasename);

// if($conn){
//      echo "connected";
// }
// else{
//     echo "Not connected";
// }
?>