<!DOCTYPE html>
<html>

<head>
    <title>userhome</title>
    <style>
        * {
            margin: 0px;
            padding: 0px;
        }

        .bgimage {
            background: url(images/userhome.jpg);
            background-size: 100% 100%;
            width: 100%;
            height: 120vh;
        }

        .menu {
            width: 100%;
            height: 70px;
            background-color: palevioletred;
            top: 0;
            position: sticky;
            z-index: 5;
        }

        .leftmenu {
            width: 25%;
            line-height: 70px;
            float: left;
        }

        .leftmenu h4 {
            padding-left: 70px;
            font-weight: bold;
            color: white;
            font-size: 28px;
            font-family: 'Montserrat', sans-serif;
        }

        .rightmenu {
            width: 75%;
            height: 70px;
            float: right;
        }

        .rightmenu ul {
            margin-left: 720px;
        }

        .rightmenu ul li {
            font-family: 'Montserrat', sans-serif;
            display: inline-block;
            list-style: none;
            font-size: 15px;
            color: white;
            font-weight: bold;
            line-height: 70px;
            margin-left: 40px;
            text-transform: uppercase;
        }

        .rightmenu ul li:hover {
            color: orange;
        }

        .body {
            width: 100%;
            margin: 0px;
            padding: 0px;
            display: flex;
            justify-items: center;
            align-items: center;
            font-family: 'Poppins', sans-serif;
        }

        .body .container {
            position: relative;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 30px 0px;
            flex-wrap: wrap;
            float: left;
        }

        .container a .box {
            position: relative;
            width: 450px;
            height: 40vh;
            padding: 20px;
            background: #fff;
            box-shadow: 5px 5px 25px black;
            border-radius: 4px;
            margin: 6vh 5vh 0 5vh;
            box-sizing: border-box;
            overflow: hidden;
            text-align: center;
            float: left;
        }

        .container a:hover {

            width: 500px;
            height: 42vh;
        }

        .container a {
            font-size: 32px;
            text-decoration: none;
            color: black;
        }

        .container a .box .content {
            position: relative;
            z-index: 1;
            font-size: 40px;
            transition: 0.5s;
            text-align: center;
            min-height: 21vh;
        }

        .container a .box .content h3 {
            margin: 10px;
            font-size: 32px;
            text-align: center;
        }

        .footer {
            bottom: 0px;
            width: 100%;
            height: 50px;
            background-color: palevioletred;
            margin-bottom: 0px;

        }
    </style>
</head>

<body>
    <div class="bgimage">
        <div class="menu">
            <div class="leftmenu">
                <h4>DIDI'S FOOD</h4>
            </div>

            <div class="rightmenu">
                <ul>
                    <a href="userhome.php">
                        <li id="firstlist"> HOME </li>
                    </a>

                    <a href="logout.php">
                        <li> LOGOUT </li>
                    </a>
                </ul>
            </div>
        </div>
        <div class="body">

            <div class="container">
                <a href="yourorder.php">
                    <div class="box">

                        <div class="content">
                            <img src="images/u1.jpg" height="190vh" width="100%">
                            <h3>Your Orders</h3>
                        </div>
                    </div>
                </a>
                <a href="order.php">
                    <div class="box">

                        <div class="content">
                            <img src="images/u2.jpg" height="190vh" width="100%">

                            <h3>order</h3>
                        </div>

                    </div>
                </a>

                <a href="">
                    <div class="box">

                        <div class="content">
                            <img src="images/u3.jpg" height="190vh" width="100%">
                            <h3>Review</h3>
                        </div>
                    </div>
                </a>


            </div>



        </div>


    </div>
    <div class="footer">
    </div>
</body>

</html>