<?php
include('connection.php');
session_start();
if(isset($_POST['sub'])){
    $food_name=$_POST['food_name'];
    $price=$_POST['price'];



$query="insert into vieworder (food_name,price) value ('$food_name','$price')";
$result=mysqli_query($conn,$query);
if($result)
{
echo "correct";
header('Location:placeorder.php');
}
else{
    echo "incorrect";
}
}

?>
<DOCTYPE! html>
    <head>
        <title>food order</title>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
        <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <style>
                    * {
            margin: 0px;
            padding: 0px;
        }

        .bgimage {
            background: url(images/userhome.jpg);
            background-size: 100% 100%;
            width: 100%;
            height: 110vh;
        }

        .menu {
            width: 100%;
            height: 70px;
            background-color: palevioletred;
            top: 0;
            position: sticky;
            z-index: 5;
        }

        .leftmenu {
            width: 25%;
            line-height: 70px;
            float: left;
        }

        .leftmenu h4 {
            padding-left: 70px;
            font-weight: bold;
            color: white;
            font-size: 28px;
            font-family: 'Montserrat', sans-serif;
        }

        .rightmenu {
            width: 75%;
            height: 70px;
            float: right;
        }

        .rightmenu ul {
            margin-left: 720px;
        }

        .rightmenu ul li {
            font-family: 'Montserrat', sans-serif;
            display: inline-block;
            list-style: none;
            font-size: 15px;
            color: white;
            font-weight: bold;
            line-height: 70px;
            margin-left: 40px;
            text-transform: uppercase;
        }

        .rightmenu ul li:hover {
            color: orange;
        }

        
        .footer {
            bottom: 0px;
            width: 100%;
            height: 50px;
            background-color: palevioletred;
            margin-bottom: 0px;

        }
        .row:after{
            content:"";
            display:table;
            clear:both;


        }
        .column{
            float:left;
            width:15%;
            padding:3vh;
            text-align:center;
            border:2px solid white;
            margin: 2vh 1.8vh ;
            background-color:#ddd;
            border-radius:15px;
            box-shadow:5px 5px 10px grey;
            
            
        }
        .image{
            width:100%;
            
            
            

        }
        .content{
            margin-top:2vh;
            text-align:left;
            width:100%;
            font-family:arial;
        }
        .content .food-title{
            color:rgb(128,128,128);
            border:none;
        }
        .rating{
            margin-top:2vh;
        }
         
         input {
             padding:1.5vh 8vh;
             margin:2vh;
             font-size:26px;
             border-radius:5px;
             background-color:#0fcfcf;
             box-shadow:5px 5px 5px grey;
             

         }
         input:hover{
             padding:1.5vh 10vh ;
             
         }
            </style>

</head>
<body>
<div class="bgimage">
            <div class="menu">
                <div class="leftmenu">
                    <h4>DIDIS FOOD </h4>
                </div>

                <div class="rightmenu">
                    <ul>
                        <a href="userhome.php"><li> HOME </li></a>
                       
                        <a href="logout.php"><li> LOGOUT </li></a>
                    </ul>
                </div>
            </div>
            <form  method="POST">
            <div class="row">
            <div class="column">
        <div class="image">
            <img src="images/u2.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <input type="text" name="food_name" class="food-title"  value="Samosa" readonly>
                       
            
            <h1> <i class="fas fa-rupee-sign"></i> <input type="text" name="price" class="food-title"  value="10" readonly></h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"style='font-size:24px; margin-right=1vh' ></i></div>

        </div>
        <input type="submit" value="order" name="sub">
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Burger
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 35</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub"></a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f2 (1).jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Pizza
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 50</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"style='font-size:24px; margin-right=1vh' ></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f2 (2).jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Sandwich
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 20</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f2 (3).jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Tea
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 15</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f3 (1).jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Noodles
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 30</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i>
            <i class="far fa-star" style='font-size:24px; margin-right=1vh'></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/f3 (2).jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                Cold Drink
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> 20</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/u1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                food name
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> price</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/u1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                food name
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> price</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/u1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                food name
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> price</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/u1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                food name
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> price</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>
    <div class="column">
        <div class="image">
            <img src="images/u1.jpg" alt="image" width="100%" height="20%">            
        </div>
        <div class="content">
        <h2>
                food name
            </h2>
            <h1> <i class="fas fa-rupee-sign"></i> price</h1>
            <div class="rating">
                <i class="far fa-star" style='font-size:24px; margin-right=1vh' ></i>
            <i class="far fa-star"></i>
            <i class="far fa-star"></i><i class="far fa-star"></i>
            <i class="far fa-star"></i></div>

        </div>
        <a href="placeorder.php"><input type="submit" value="order" name="sub">""</a>
    </div>

    
       
</div>
</form>
    
    </div>
            <div class="footer">        
            </div>
    

</body>
</html>